baseName = {
  //Prob image upload url
  imageUploadPath: "https://roi.kreativemachinez.in/uploads/",
};

module.exports = Object.freeze(baseName);
