// // const { db, sequelize } = require("./conn");

// // db.influencer_users.belongsTo(db.City, {
// //   foreignKey: "city_id", // foreign table
// //   targetKey: "city_id", // primary table
// // });

// // module.exports = {
// //   db,
// // };

// module.exports = (sequelize, DataTypes) => {
//    testn = [db.influencer.belongsTo(db.City, {
//         foreignKey: "city_id", // foreign table
//         targetKey: "city_id", // primary table
//       }),

//       db.influencer.belongsTo(db.state, {
//         foreignKey: "state_id", // foreign table
//         targetKey: "state_id", // primary table
//       }),]

//     return test
// }
