// const express = require("express");
// const router = express.Router();

// const {
//   addComments,
//   getinfluencerComments,
//   getBrandsComments,
//   deleteComments,
//   addNotes,
// } = require("../../controllers/comments/comments.controller.js");

// router.post("/add/", (req, res) => {
//   addComments(req, res);
// });

// router.post("/add-notes/:campaign_applied_id", (req, res) => {
//   addNotes(req, res);
// });
// router.get("/get-influencer/:campaign_applied_id", (req, res) => {
//   getinfluencerComments(req, res);
// });

// router.get("/get-brands/:campaign_applied_id/:influencer_id", (req, res) => {
//   getBrandsComments(req, res);
// });

// router.delete("/delete/:comment_id", (req, res) => {
//   deleteComments(req, res);
// });

// module.exports = router;
